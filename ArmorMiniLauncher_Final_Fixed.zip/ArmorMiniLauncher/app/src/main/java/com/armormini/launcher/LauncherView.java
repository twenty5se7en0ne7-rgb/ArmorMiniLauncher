package com.armormini.launcher;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.BatteryManager;
import android.os.Handler;
import android.os.Looper;
import android.provider.ContactsContract;
import android.text.TextUtils;
import android.text.TextPaint;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashSet;

/** Single custom view. Everything is drawn in a native 240x320 coordinate space. */
public class LauncherView extends View {
    static final int W = 240, H = 320, ROW = 24, ROWS = 11, LT = 26, BAR = 28, HOME_Y = 146, HOME_ROW = 26;
    static final int BG = 0xFF000000, FG = 0xFFFFFFFF, DIM = 0xFF8A8A8A, LINE = 0xFF262626,
            SEL = 0xFF2E2E2E, ACC = 0xFFF5A623, PANEL = 0xFF111111;
    static final String[] DAYS = {"Yakshanba", "Dushanba", "Seshanba", "Chorshanba", "Payshanba", "Juma", "Shanba"};
    static final String[] MON = {"yanvar", "fevral", "mart", "aprel", "may", "iyun", "iyul", "avgust",
            "sentabr", "oktabr", "noyabr", "dekabr"};
    static final String[] T9 = {"abc", "def", "ghi", "jkl", "mno", "pqrs", "tuv", "wxyz"};

    static class App {
        String label, low, t9, key;
        ComponentName cn;
        Bitmap icon;
    }

    private final ArrayList<App> all = new ArrayList<>(), list = new ArrayList<>();
    private final HashSet<String> favs = new HashSet<>();
    private final TextPaint tp = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final Paint sp = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ip = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final RectF rf = new RectF();
    private final SharedPreferences prefs;
    private final Handler ui = new Handler(Looper.getMainLooper());

    private boolean menu, search, charging, wifi;
    private String query = "";
    private int sel, top, homeSel = -1, battery = -1, sig;
    private float s = 1, ox, oy;

    public LauncherView(Context c) {
        super(c);
        prefs = c.getSharedPreferences("launcher", Context.MODE_PRIVATE);
        favs.addAll(prefs.getStringSet("fav", new HashSet<String>()));
        tp.setTypeface(Typeface.SANS_SERIF);
        ColorMatrix cm = new ColorMatrix();
        cm.setSaturation(0f);
        ip.setColorFilter(new ColorMatrixColorFilter(cm));
        reload();
    }

    // ---------- data ----------
    void reload() {
        new Thread(new Runnable() {
            @Override public void run() {
                Context c = getContext();
                PackageManager pm = c.getPackageManager();
                Intent q = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
                final ArrayList<App> out = new ArrayList<>();
                for (ResolveInfo r : pm.queryIntentActivities(q, 0)) {
                    if (r.activityInfo.packageName.equals(c.getPackageName())) continue;
                    App a = new App();
                    a.label = String.valueOf(r.loadLabel(pm));
                    a.low = a.label.toLowerCase();
                    a.t9 = t9(a.low);
                    a.cn = new ComponentName(r.activityInfo.packageName, r.activityInfo.name);
                    a.key = a.cn.flattenToShortString();
                    a.icon = bmp(r.loadIcon(pm));
                    out.add(a);
                }
                Collections.sort(out, new java.util.Comparator<App>() {
                    @Override public int compare(App x, App y) { return x.low.compareTo(y.low); }
                });
                ui.post(new Runnable() {
                    @Override public void run() {
                        all.clear();
                        all.addAll(out);
                        refilter(null);
                        invalidate();
                    }
                });
            }
        }).start();
    }

    static Bitmap bmp(Drawable d) {
        Bitmap b = Bitmap.createBitmap(20, 20, Bitmap.Config.ARGB_8888);
        d.setBounds(0, 0, 20, 20);
        d.draw(new Canvas(b));
        return b;
    }

    static String t9(String s) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch >= '0' && ch <= '9') b.append(ch);
            else if (ch == ' ') b.append('0');
            else for (int k = 0; k < T9.length; k++) if (T9[k].indexOf(ch) >= 0) { b.append((char) ('2' + k)); break; }
        }
        return b.toString();
    }

    static boolean digits(String s) {
        for (int i = 0; i < s.length(); i++) if (s.charAt(i) < '0' || s.charAt(i) > '9') return false;
        return s.length() > 0;
    }

    private boolean match(App a) {
        if (a.low.contains(query)) return true;
        if (digits(query)) return a.t9.startsWith(query);
        return false;
    }

    private void refilter(App keep) {
        list.clear();
        for (int pass = 0; pass < 2; pass++)
            for (App a : all) {
                if (favs.contains(a.key) != (pass == 0)) continue;
                if (query.length() == 0 || match(a)) list.add(a);
            }
        int i = keep == null ? -1 : list.indexOf(keep);
        sel = i >= 0 ? i : 0;
        if (list.isEmpty()) { sel = 0; top = 0; }
        fix();
    }

    private void fix() {
        if (sel < top) top = sel;
        if (sel >= top + ROWS) top = sel - ROWS + 1;
        if (top < 0) top = 0;
    }

    private ArrayList<App> favApps() {
        ArrayList<App> f = new ArrayList<>();
        for (App a : all) if (favs.contains(a.key)) f.add(a);
        return f;
    }

    // ---------- status ----------
    void setSignal(int level) { sig = level; invalidate(); }

    void onBroadcast(Intent i) {
        if (i != null && Intent.ACTION_BATTERY_CHANGED.equals(i.getAction())) {
            int l = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1), sc = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            battery = l < 0 ? -1 : l * 100 / sc;
            int st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL;
        }
        try {
            ConnectivityManager cm = (ConnectivityManager) getContext().getSystemService(Context.CONNECTIVITY_SERVICE);
            Network n = cm.getActiveNetwork();
            NetworkCapabilities nc = n == null ? null : cm.getNetworkCapabilities(n);
            wifi = nc != null && nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI);
        } catch (Exception e) { wifi = false; }
        invalidate();
    }

    // ---------- actions ----------
    void goHome() { menu = false; search = false; query = ""; homeSel = -1; refilter(null); invalidate(); }

    private void openMenu(boolean srch) { menu = true; search = srch; query = ""; refilter(null); invalidate(); }

    private void back() {
        if (!menu) return;
        if (search) { search = false; query = ""; refilter(null); } else goHome();
        invalidate();
    }

    private void launch(App a) {
        try {
            Intent i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(a.cn)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
            getContext().startActivity(i);
        } catch (Exception ignored) { }
    }

    private void contacts() {
        try {
            getContext().startActivity(new Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.CONTENT_URI)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception ignored) { }
    }

    private void dial() {
        try { getContext().startActivity(new Intent(Intent.ACTION_DIAL).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); }
        catch (Exception ignored) { }
    }

    private void toggleFav() {
        if (sel >= list.size()) return;
        App a = list.get(sel);
        if (!favs.remove(a.key)) favs.add(a.key);
        prefs.edit().putStringSet("fav", new HashSet<>(favs)).apply();
        homeSel = -1;
        refilter(a);
    }

    private void softL() {
        if (menu) { if (sel < list.size()) launch(list.get(sel)); } else openMenu(false);
    }

    private void softR() { if (menu) back(); else contacts(); }

    // ---------- input ----------
    static int digit(int k) {
        if (k >= KeyEvent.KEYCODE_0 && k <= KeyEvent.KEYCODE_9) return k - KeyEvent.KEYCODE_0;
        if (k >= KeyEvent.KEYCODE_NUMPAD_0 && k <= KeyEvent.KEYCODE_NUMPAD_9) return k - KeyEvent.KEYCODE_NUMPAD_0;
        return -1;
    }

    boolean key(int k, KeyEvent e) {
        if (e.getRepeatCount() > 0 && k != KeyEvent.KEYCODE_DPAD_UP && k != KeyEvent.KEYCODE_DPAD_DOWN) return true;
        if (k == KeyEvent.KEYCODE_BACK) { back(); return true; }
        if (k == KeyEvent.KEYCODE_CALL) { dial(); return true; }
        return menu ? menuKey(k, e, digit(k)) : homeKey(k, e, digit(k));
    }

    private boolean homeKey(int k, KeyEvent e, int d) {
        ArrayList<App> f = favApps();
        int n = Math.min(f.size(), 4);
        switch (k) {
            case KeyEvent.KEYCODE_DPAD_UP: if (homeSel >= 0) homeSel--; break;
            case KeyEvent.KEYCODE_DPAD_DOWN: if (homeSel < n - 1) homeSel++; break;
            case KeyEvent.KEYCODE_DPAD_LEFT:
            case KeyEvent.KEYCODE_SOFT_LEFT:
            case KeyEvent.KEYCODE_MENU: openMenu(false); return true;
            case KeyEvent.KEYCODE_DPAD_RIGHT:
            case KeyEvent.KEYCODE_SOFT_RIGHT: contacts(); return true;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_NUMPAD_ENTER:
                if (homeSel >= 0 && homeSel < n) launch(f.get(homeSel)); else openMenu(false);
                return true;
            case KeyEvent.KEYCODE_POUND: openMenu(true); return true;
            default:
                if (d >= 1) { if (d - 1 < f.size()) launch(f.get(d - 1)); return true; }
                if (d == 0) return true;
                int u = e.getUnicodeChar();
                if (u > 0 && Character.isLetter(u)) {
                    openMenu(true);
                    query += Character.toLowerCase((char) u);
                    refilter(null);
                    invalidate();
                    return true;
                }
                return false;
        }
        invalidate();
        return true;
    }

    private boolean menuKey(int k, KeyEvent e, int d) {
        int n = list.size();
        switch (k) {
            case KeyEvent.KEYCODE_DPAD_UP: if (n > 0) { sel = sel > 0 ? sel - 1 : n - 1; fix(); } break;
            case KeyEvent.KEYCODE_DPAD_DOWN: if (n > 0) { sel = sel < n - 1 ? sel + 1 : 0; fix(); } break;
            case KeyEvent.KEYCODE_DPAD_LEFT: sel = Math.max(0, sel - ROWS); fix(); break;
            case KeyEvent.KEYCODE_DPAD_RIGHT: if (n > 0) { sel = Math.min(n - 1, sel + ROWS); fix(); } break;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_NUMPAD_ENTER:
            case KeyEvent.KEYCODE_SOFT_LEFT: softL(); return true;
            case KeyEvent.KEYCODE_SOFT_RIGHT: back(); return true;
            case KeyEvent.KEYCODE_STAR:
            case KeyEvent.KEYCODE_MENU: toggleFav(); break;
            case KeyEvent.KEYCODE_POUND:
                if (search) { back(); return true; }
                search = true; query = ""; refilter(null); break;
            case KeyEvent.KEYCODE_DEL:
            case KeyEvent.KEYCODE_CLEAR:
                if (query.length() > 0) { query = query.substring(0, query.length() - 1); refilter(null); }
                else { back(); return true; }
                break;
            default:
                if (d >= 0) {
                    if (search) { query += d; refilter(null); }
                    else if (d >= 1) { int i = top + d - 1; if (i < n) launch(list.get(i)); }
                    break;
                }
                int u = e.getUnicodeChar();
                if (u > 0 && Character.isLetter(u)) {
                    search = true;
                    query += Character.toLowerCase((char) u);
                    refilter(null);
                    break;
                }
                return false;
        }
        invalidate();
        return true;
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (e.getAction() != MotionEvent.ACTION_UP) return true;
        float x = (e.getX() - ox) / s, y = (e.getY() - oy) / s;
        if (y >= H - BAR) { if (x < W / 2f) softL(); else softR(); invalidate(); return true; }
        if (menu) {
            if (y >= LT && y < LT + ROWS * ROW) {
                int i = top + (int) ((y - LT) / ROW);
                if (i < list.size()) {
                    if (x > 212) { sel = i; toggleFav(); }
                    else if (i == sel) launch(list.get(i));
                    else sel = i;
                }
            }
        } else if (y >= HOME_Y) {
            ArrayList<App> f = favApps();
            int i = (int) ((y - HOME_Y) / HOME_ROW);
            if (i < Math.min(f.size(), 4)) { homeSel = i; launch(f.get(i)); }
        }
        invalidate();
        return true;
    }

    // ---------- drawing ----------
    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        s = Math.min(w / (float) W, h / (float) H);
        ox = (w - W * s) / 2f;
        oy = (h - H * s) / 2f;
    }

    @Override protected void onDraw(Canvas c) {
        c.drawColor(BG);
        c.translate(ox, oy);
        c.scale(s, s);
        c.clipRect(0, 0, W, H);
        if (menu) drawMenu(c); else drawHome(c);
        bar(c, menu ? "Ochish" : "Menyu", menu ? "Orqaga" : "Kontakt");
    }

    private void r(Canvas c, float l, float t, float rr, float b, int col) {
        sp.setStyle(Paint.Style.FILL);
        sp.setColor(col);
        c.drawRect(l, t, rr, b, sp);
    }

    private void t(Canvas c, String x, float px, float py, float size, int col, boolean bold, Paint.Align al) {
        tp.setTextSize(size);
        tp.setColor(col);
        tp.setFakeBoldText(bold);
        tp.setTextAlign(al);
        c.drawText(x, px, py, tp);
    }

    private void bar(Canvas c, String l, String rt) {
        r(c, 0, H - BAR, W, H, PANEL);
        r(c, 0, H - BAR, W, H - BAR + 1, LINE);
        t(c, l, 8, H - 9, 15, FG, true, Paint.Align.LEFT);
        t(c, rt, W - 8, H - 9, 15, FG, true, Paint.Align.RIGHT);
    }

    private void drawStatus(Canvas c) {
        for (int i = 0; i < 4; i++) {
            int h = 4 + i * 3;
            r(c, 6 + i * 6, 17 - h, 10 + i * 6, 17, i < sig ? FG : 0xFF444444);
        }
        sp.setStyle(Paint.Style.STROKE);
        sp.setStrokeWidth(1.5f);
        sp.setColor(wifi ? FG : 0xFF444444);
        for (int k = 1; k <= 3; k++) {
            float rr = k * 4;
            rf.set(50 - rr, 18 - rr, 50 + rr, 18 + rr);
            c.drawArc(rf, 225, 90, false, sp);
        }
        sp.setStyle(Paint.Style.FILL);
        c.drawCircle(50, 17.5f, 1.3f, sp);
        if (battery >= 0) {
            t(c, (charging ? "+" : "") + battery + "%", 206, 17, 13, FG, false, Paint.Align.RIGHT);
            sp.setStyle(Paint.Style.STROKE);
            sp.setStrokeWidth(1);
            sp.setColor(FG);
            c.drawRect(212, 8, 232, 18, sp);
            r(c, 232, 11, 234, 15, FG);
            r(c, 213, 9, 213 + 18f * battery / 100f, 17, battery <= 15 ? 0xFFE04040 : FG);
        }
        r(c, 0, 22, W, 23, LINE);
    }

    private void drawHome(Canvas c) {
        drawStatus(c);
        Calendar cal = Calendar.getInstance();
        int hh = cal.get(Calendar.HOUR_OF_DAY), mm = cal.get(Calendar.MINUTE);
        String time = (hh < 10 ? "0" : "") + hh + ":" + (mm < 10 ? "0" : "") + mm;
        tp.setTypeface(Typeface.MONOSPACE);
        t(c, time, 120, 92, 56, FG, true, Paint.Align.CENTER);
        tp.setTypeface(Typeface.SANS_SERIF);
        t(c, DAYS[cal.get(Calendar.DAY_OF_WEEK) - 1] + ", " + cal.get(Calendar.DAY_OF_MONTH) + " "
                + MON[cal.get(Calendar.MONTH)], 120, 118, 15, DIM, false, Paint.Align.CENTER);
        r(c, 90, 130, 150, 131, 0xFF333333);
        ArrayList<App> f = favApps();
        int n = Math.min(f.size(), 4);
        if (n == 0) t(c, "Menyuda * - sevimli", 120, 176, 13, DIM, false, Paint.Align.CENTER);
        for (int i = 0; i < n; i++) row(c, f.get(i), i + 1, HOME_Y + i * HOME_ROW, i == homeSel, false);
    }

    private void drawMenu(Canvas c) {
        r(c, 0, 0, W, 24, PANEL);
        r(c, 0, 24, W, 25, LINE);
        t(c, search ? "Qidiruv: " + query + "_" : "Ilovalar", 8, 17, 15, FG, true, Paint.Align.LEFT);
        if (!list.isEmpty()) t(c, (sel + 1) + "/" + list.size(), W - 8, 17, 12, DIM, false, Paint.Align.RIGHT);
        for (int i = 0; i < ROWS; i++) {
            int idx = top + i;
            if (idx >= list.size()) break;
            App a = list.get(idx);
            row(c, a, i + 1, LT + i * ROW, idx == sel, favs.contains(a.key));
        }
        int n = list.size();
        if (n > ROWS) {
            float th = ROWS * ROW * (float) ROWS / n;
            float ty = LT + (ROWS * ROW - th) * top / (n - ROWS);
            r(c, 237, ty, 240, ty + th, 0xFF555555);
        }
        if (n == 0) t(c, "Topilmadi", 120, 150, 15, DIM, false, Paint.Align.CENTER);
    }

    private void row(Canvas c, App a, int num, float y, boolean on, boolean star) {
        if (on) { r(c, 0, y, W, y + ROW, SEL); r(c, 0, y, 3, y + ROW, ACC); }
        if (num >= 1 && num <= 9) t(c, String.valueOf(num), 14, y + 17, 13, on ? ACC : DIM, false, Paint.Align.CENTER);
        c.drawBitmap(a.icon, 26, y + 2, ip);
        tp.setTextSize(15);
        String lbl = TextUtils.ellipsize(a.label, tp, 156, TextUtils.TruncateAt.END).toString();
        t(c, lbl, 52, y + 17, 15, FG, on, Paint.Align.LEFT);
        if (star) t(c, "*", 228, y + 19, 16, ACC, true, Paint.Align.CENTER);
    }
}
