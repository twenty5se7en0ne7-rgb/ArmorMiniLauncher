ArmorMiniLauncher - Ulefone Armor Mini 5
========================================

Loyiha:
- Android HOME launcher uchun Java custom View.
- 240x320 canvas coordinate space.
- D-pad/keypad navigatsiyasi, ilovalar ro'yxati, fav belgilash, T9, soat/sana.
- Package broadcast refresh hooks (installed/uninstalled/replaced) mavjud.

Hozirgi tugma mapping (koddagi implementatsiyaga asoslangan):
- D-pad Up/Down: tanlovni siljitish.
- D-pad Center/Enter: tanlangan ilovani ochish; home'da menu yoki tanlangan favorite.
- Home'da 1-4: favorite ro'yxatidagi mos indeksni ochish (favorite ro'yxati mavjud bo'lsa).
- * / Menu: ilova ro'yxatida favorite toggle.
- #: home'da search/menu flow, list'da search.
- Back: ortга/чиқиш.
- Call: dialer.
- Soft-left/right: меню/контакт ёки орқага (контекстга боғлиқ).

Build:
1. Android Studio ўрнатинг.
2. ZIP'ни очиб, ArmorMiniLauncher папкасини Android Studio'да Open қилинг.
3. Gradle Sync кутинг.
4. Build > Build APK(s).
5. APK app/build/outputs/apk/debug/ папкасида чиқиши керак.

Known limitations:
- APK ushbu muhitda build qilinmagan.
- Ulefone Armor Mini 5 real qurilmada test qilinmagan.
- Signal, contacts, keypad mappings va T9 telefon firmware'ida test talab qiladi.
- Settings panel, theme/font controls va favorites rearrangement hozircha implement qilinmagan.
