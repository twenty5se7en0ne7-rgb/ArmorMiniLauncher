package com.armormini.launcher;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.telephony.PhoneStateListener;
import android.telephony.SignalStrength;
import android.telephony.TelephonyManager;
import android.view.KeyEvent;

public class MainActivity extends Activity {
    private LauncherView v;
    private TelephonyManager tm;
    private PhoneStateListener sl;

    private final BroadcastReceiver tick = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) { v.onBroadcast(i); }
    };
    private final BroadcastReceiver pkgs = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) { v.reload(); }
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        v = new LauncherView(this);
        setContentView(v);
        IntentFilter pf = new IntentFilter();
        pf.addAction(Intent.ACTION_PACKAGE_ADDED);
        pf.addAction(Intent.ACTION_PACKAGE_REMOVED);
        pf.addAction(Intent.ACTION_PACKAGE_REPLACED);
        pf.addDataScheme("package");
        registerReceiver(pkgs, pf);
    }

    @Override protected void onResume() {
        super.onResume();
        IntentFilter f = new IntentFilter(Intent.ACTION_TIME_TICK);
        f.addAction(Intent.ACTION_BATTERY_CHANGED);
        f.addAction(Intent.ACTION_TIME_CHANGED);
        f.addAction(Intent.ACTION_TIMEZONE_CHANGED);
        Intent sticky = registerReceiver(tick, f);
        v.onBroadcast(sticky);
        tm = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
        if (tm != null) {
            sl = new PhoneStateListener() {
                @Override public void onSignalStrengthsChanged(SignalStrength s) {
                    try { v.setSignal(s.getLevel()); } catch (Exception ignored) { }
                }
            };
            try { tm.listen(sl, PhoneStateListener.LISTEN_SIGNAL_STRENGTHS); }
            catch (SecurityException ignored) { v.setSignal(0); }
        }
    }

    @Override protected void onPause() {
        super.onPause();
        try { unregisterReceiver(tick); } catch (Exception ignored) { }
        if (tm != null && sl != null) tm.listen(sl, PhoneStateListener.LISTEN_NONE);
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        try { unregisterReceiver(pkgs); } catch (Exception ignored) { }
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        v.goHome();
    }

    @Override public boolean onKeyDown(int k, KeyEvent e) {
        if (v.key(k, e)) return true;
        return super.onKeyDown(k, e);
    }
}
